## API Location Information

Table list as of 2017/10/01:


* Nightfall
* Flashpoint

### Nightfall
Endpoint: https://www.bungie.net/Platform/Destiny2/Milestones/

JSON Path: Response.2171429505.availableQuests.0.activity

Components:
* Event name
* Modifiers
* Challenges
* Beginning and ending dates

### Flashpoint
Endpoint: https://www.bungie.net/Platform/Destiny2/Milestones/

JSON Path: Response.463010297.availableQuests

Components:
* Location
* Beginning and ending dates