# Destiny2-API-Info
Some unofficial information I've collected about the Bungie Destiny 2 API

[See the Wiki](https://github.com/vpzed/Destiny2-API-Info/wiki)

If would like to contribute to this Wiki please fork  https://github.com/vpzed/Destiny2-API-Info-wiki  and submit a pull request there.
Once merged those changes will be applied to the Wiki here.
